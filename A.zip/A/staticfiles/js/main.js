{% extends 'base.html' %}
{% block title %}Register{% endblock %}

{% block content %}
<div class="auth-wrapper">
    <div class="auth-card">
        <h2 class="mb-4">Create Account</h2>
        
        <form method="post" class="needs-validation" novalidate>
            {% csrf_token %}
            
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" 
                       name="username" 
                       class="form-control"
                       required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group">
                    <input type="password" 
                           name="password1" 
                           class="form-control"
                           required>
                    <button type="button" class="btn btn-outline-secondary password-toggle">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Confirm Password</label>
                <div class="input-group">
                    <input type="password" 
                           name="password2" 
                           class="form-control"
                           required>
                    <button type="button" class="btn btn-outline-secondary password-toggle">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100 mb-3">
                <i class="bi bi-person-plus"></i> Register
            </button>

            <div class="text-center">
                Already have an account? 
                <a href="{% url 'login' %}" class="text-decoration-none">
                    Sign In
                </a>
            </div>
        </form>
    </div>
</div>
{% endblock %}
